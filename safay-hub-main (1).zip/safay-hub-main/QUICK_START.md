# Quick Start Guide 🚀

## You're Almost Ready!

Your Safay Hub project uses **Firestore** for data and **Cloudinary** for images - the best of both worlds!

## Step 1: Configure Cloudinary (5 minutes)

Since you already have a Cloudinary account:

1. Go to [Cloudinary Dashboard](https://cloudinary.com/console)
2. Copy your **Cloud Name** (shown on dashboard)
3. Go to **Settings > Upload > Upload Presets**
4. Click **"Add upload preset"**
5. Set **Signing Mode** to **"Unsigned"** ⚠️ (Important!)
6. Name it (e.g., `safay_hub_unsigned`)
7. Click **Save**

**Detailed guide**: See [CLOUDINARY_SETUP.md](./CLOUDINARY_SETUP.md)

## Step 2: Update .env File (1 minute)

Open `.env` and add your Cloudinary credentials:

```env
# Your Firebase config is already there

# Add these Cloudinary values:
VITE_CLOUDINARY_CLOUD_NAME=your_cloud_name_here
VITE_CLOUDINARY_UPLOAD_PRESET=safay_hub_unsigned
```

## Step 3: Start Your App (1 minute)

```bash
# Install dependencies (if not already done)
npm install

# Start development server
npm run dev
```

Your app should now open at `http://localhost:5173`

## Step 4: Test It! (2 minutes)

1. Go to **"Add Employee"** page
2. Fill in employee details
3. Upload a photo and Aadhar document
4. Click "Add Employee"
5. Navigate to **"All Workers"** to see your employee
6. Check the **Dashboard** for updated statistics

## ✅ Success Indicators

- ✅ No error messages in browser console
- ✅ Employee appears in "All Workers" page
- ✅ Photos are visible
- ✅ Dashboard shows correct counts
- ✅ Data appears in Firebase Console > Firestore Database
- ✅ Images appear in Cloudinary Media Library

## 🎉 You're Done!

Your Safay Hub is now running with:
- 🔥 **Firestore** for data (employees, inquiries, etc.)
- 🖼️ **Cloudinary** for images (25 GB free!)

## 📚 Need More Help?

- **Cloudinary Setup**: See [CLOUDINARY_SETUP.md](./CLOUDINARY_SETUP.md)
- **Firebase Setup**: See [FIREBASE_SETUP.md](./FIREBASE_SETUP.md)
- **Technical Details**: See [INTEGRATION_SUMMARY.md](./INTEGRATION_SUMMARY.md)

## Common First-Time Issues

### "Cloudinary credentials not configured"
**Fix**: Check your `.env` file has the correct cloud name and upload preset

### "Upload failed with status 400"
**Fix**: Make sure your upload preset is set to **"Unsigned"** mode

### "Missing or insufficient permissions" (Firestore)
**Fix**: Make sure Firestore is in **test mode** in Firebase Console

---

**Need help? All details are in CLOUDINARY_SETUP.md and FIREBASE_SETUP.md!**

Happy coding! 🎉
