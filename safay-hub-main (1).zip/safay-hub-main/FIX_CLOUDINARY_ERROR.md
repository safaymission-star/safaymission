# 🚨 URGENT FIX: Cloudinary 400 Error

## Problem
```
POST https://api.cloudinary.com/v1_1/dcnw6lrcq/image/upload 400 (Bad Request)
```

## ✅ Solution (3 Steps - Takes 2 Minutes)

### Step 1: Create Upload Preset in Cloudinary

1. **Go to Cloudinary Dashboard:**
   ```
   https://cloudinary.com/console
   ```

2. **Navigate to Settings:**
   - Click ⚙️ **Settings** (top right corner)
   - Click **Upload** tab
   - Scroll down to **Upload presets** section

3. **Create New Upload Preset:**
   - Click **"Add upload preset"**
   - Fill in:
     ```
     Preset name: safay_hub_unsigned
     Signing mode: Unsigned ⚠️ (VERY IMPORTANT!)
     ```
   - Click **Save**

### Step 2: Restart Your Dev Server

```bash
# Stop the current server (press Ctrl+C in terminal)
# Then restart:
npm run dev
# or if using bun:
bun run dev
```

⚠️ **This is crucial!** Vite needs to be restarted after the preset is created.

### Step 3: Test Upload

1. Open your app: http://localhost:5173
2. Go to **Add Employee**
3. Select a small test image
4. Try uploading

---

## 🧪 Optional: Test Independently

If it still doesn't work, use the test file to debug:

```bash
# Open the test file in your browser
open test-cloudinary.html
```

This will help identify if the issue is with:
- Upload preset configuration
- Network connectivity
- File format
- Your app code

---

## 📋 What Was Fixed in Code

### Removed These Lines (Causing 400 Error):
```typescript
// ❌ These require SIGNED uploads
formData.append("public_id", `${Date.now()}_${file.name.split('.')[0]}`);
formData.append("transformation", "q_auto,f_auto,w_800,h_800,c_limit");
```

### Kept Only Essential Parameters:
```typescript
// ✅ Works with UNSIGNED uploads
formData.append("file", file);
formData.append("upload_preset", uploadPreset);
formData.append("folder", folder); // optional
```

### Added Better Error Logging:
Now you'll see detailed error messages in the browser console that explain exactly what went wrong.

---

## 🎯 Why This Happened

The upload preset **`safay_hub_unsigned`** needs to exist in your Cloudinary account:
- It tells Cloudinary to accept unsigned uploads
- Without it, Cloudinary rejects the upload with 400 error
- It must be created manually in the dashboard

---

## ✅ Success Indicators

When working, you'll see:
```
✅ Compressing image...
✅ Compressed to 180 KB
✅ Photo uploaded successfully
```

---

## 📞 Still Having Issues?

Check the detailed troubleshooting guide:
```
CLOUDINARY_UPLOAD_ERROR.md
```

Or test with the standalone HTML file:
```
test-cloudinary.html
```

---

## 🎯 TL;DR

1. **Create upload preset** named `safay_hub_unsigned` with **Unsigned** mode in Cloudinary Dashboard
2. **Restart dev server**: `npm run dev` or `bun run dev`
3. **Test upload** in your app

That's it! 🚀
