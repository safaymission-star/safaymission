# Cloudinary Upload Error - Troubleshooting Guide

## 🚨 Error: 400 Bad Request on Image Upload

### Common Causes & Solutions

---

## ✅ Solution 1: Verify Upload Preset (Most Common)

The upload preset `safay_hub_unsigned` must be properly configured in your Cloudinary dashboard.

### Steps to Check/Create Upload Preset:

1. **Go to Cloudinary Dashboard**
   ```
   https://cloudinary.com/console
   ```

2. **Navigate to Settings**
   - Click on the ⚙️ **Settings** (top right)
   - Go to **Upload** tab
   - Scroll to **Upload presets** section

3. **Check if `safay_hub_unsigned` exists**
   - Look for a preset named `safay_hub_unsigned`
   - If it doesn't exist, create it:

4. **Create Upload Preset**
   - Click **Add upload preset**
   - **Preset name:** `safay_hub_unsigned`
   - **Signing mode:** ⚠️ **UNSIGNED** (very important!)
   - **Use filename:** Enable (optional)
   - **Unique filename:** Enable (recommended)
   - **Folder:** Leave empty or set default folder
   - Click **Save**

5. **Important Settings:**
   ```
   Signing Mode: Unsigned ✅ (MUST be unsigned!)
   Overwrite: No
   Unique Filename: Yes
   Access Mode: Public
   ```

### Visual Guide:
```
Cloudinary Dashboard
  └── Settings (⚙️)
      └── Upload tab
          └── Upload presets
              └── Add upload preset
                  ├── Name: safay_hub_unsigned
                  ├── Signing mode: Unsigned ⚠️
                  ├── Unique filename: Yes
                  └── Click Save
```

---

## ✅ Solution 2: Check Environment Variables

### Verify `.env` file:
```bash
# In your project root
cat .env
```

Should show:
```env
VITE_CLOUDINARY_CLOUD_NAME=dcnw6lrcq
VITE_CLOUDINARY_UPLOAD_PRESET=safay_hub_unsigned
```

### Restart Dev Server (Important!):
```bash
# Stop current server (Ctrl+C)
# Then restart:
npm run dev
# or
bun run dev
```

⚠️ **Vite requires restart after .env changes!**

---

## ✅ Solution 3: Test Cloudinary Connection

### Create Test Script:

Create file: `/test-cloudinary.html`

```html
<!DOCTYPE html>
<html>
<head>
  <title>Cloudinary Upload Test</title>
</head>
<body>
  <h1>Test Cloudinary Upload</h1>
  <input type="file" id="fileInput" accept="image/*">
  <button onclick="testUpload()">Test Upload</button>
  <div id="result"></div>

  <script>
    async function testUpload() {
      const file = document.getElementById('fileInput').files[0];
      if (!file) {
        alert('Please select a file');
        return;
      }

      const formData = new FormData();
      formData.append('file', file);
      formData.append('upload_preset', 'safay_hub_unsigned');
      formData.append('cloud_name', 'dcnw6lrcq');

      try {
        const response = await fetch(
          'https://api.cloudinary.com/v1_1/dcnw6lrcq/image/upload',
          {
            method: 'POST',
            body: formData
          }
        );

        const data = await response.json();
        
        if (response.ok) {
          document.getElementById('result').innerHTML = 
            `<p style="color: green;">✅ Success! URL: ${data.secure_url}</p>`;
          console.log('Upload successful:', data);
        } else {
          document.getElementById('result').innerHTML = 
            `<p style="color: red;">❌ Error: ${JSON.stringify(data.error)}</p>`;
          console.error('Upload failed:', data);
        }
      } catch (error) {
        document.getElementById('result').innerHTML = 
          `<p style="color: red;">❌ Network Error: ${error.message}</p>`;
        console.error('Network error:', error);
      }
    }
  </script>
</body>
</html>
```

**How to use:**
1. Save the file in your project root
2. Open it in a browser: `open test-cloudinary.html`
3. Select an image and click "Test Upload"
4. Check browser console for detailed error

---

## ✅ Solution 4: Common Error Messages

### Error: "Upload preset must be whitelisted"
**Cause:** Upload preset doesn't exist or is spelled wrong
**Fix:** 
- Double-check preset name: `safay_hub_unsigned`
- Create it in Cloudinary Dashboard (see Solution 1)

### Error: "Upload preset not found"
**Cause:** Preset name mismatch
**Fix:**
```bash
# Check your .env file
cat .env | grep UPLOAD_PRESET

# Should show:
VITE_CLOUDINARY_UPLOAD_PRESET=safay_hub_unsigned
```

### Error: "Invalid signature"
**Cause:** Using signed upload with unsigned preset
**Fix:** Ensure preset is set to **Unsigned** in dashboard

### Error: "Resource type not allowed"
**Cause:** Upload preset doesn't allow images
**Fix:** In upload preset settings, ensure "Resource type: image" is allowed

---

## ✅ Solution 5: Network/CORS Issues

### Check Browser Console:
1. Open DevTools (F12)
2. Go to **Network** tab
3. Try uploading again
4. Click on failed request
5. Check:
   - Request payload
   - Response headers
   - Error message

### Expected Request:
```
Method: POST
URL: https://api.cloudinary.com/v1_1/dcnw6lrcq/image/upload
Content-Type: multipart/form-data

Body:
  file: [binary data]
  upload_preset: safay_hub_unsigned
  folder: employees/photos (optional)
```

### Expected Response (Success):
```json
{
  "public_id": "employees/photos/abc123",
  "version": 1234567890,
  "signature": "...",
  "secure_url": "https://res.cloudinary.com/dcnw6lrcq/image/upload/v1234567890/employees/photos/abc123.jpg",
  ...
}
```

---

## ✅ Solution 6: Image File Issues

### Check File Requirements:
```javascript
// Maximum file size (Cloudinary free tier)
Max size: 10MB per image

// Supported formats
Formats: JPG, PNG, GIF, BMP, TIFF, WebP

// Your compression settings
Target: 800x800px, 70% quality, ~200KB
```

### Test with Small Image:
1. Use a small test image (< 1MB)
2. Try PNG and JPG formats
3. Verify file is not corrupted

---

## 🔧 Quick Fix Checklist

Run through this checklist:

- [ ] **Upload preset exists** in Cloudinary Dashboard
- [ ] **Preset is UNSIGNED** (not signed)
- [ ] **Preset name matches** `.env` file exactly
- [ ] **Dev server restarted** after .env changes
- [ ] **Cloud name correct**: `dcnw6lrcq`
- [ ] **No typos** in preset name
- [ ] **Browser console checked** for detailed errors
- [ ] **Network tab checked** for request/response
- [ ] **Test image is valid** (< 10MB, JPG/PNG)
- [ ] **Internet connection** working

---

## 🎯 Step-by-Step Fix Process

### Step 1: Verify Upload Preset
```bash
# 1. Go to Cloudinary Dashboard
open https://cloudinary.com/console

# 2. Settings → Upload → Upload presets
# 3. Look for: safay_hub_unsigned
# 4. If missing, create it (Signing mode: Unsigned)
```

### Step 2: Verify Environment
```bash
# Check .env file
cat .env

# Should have:
# VITE_CLOUDINARY_CLOUD_NAME=dcnw6lrcq
# VITE_CLOUDINARY_UPLOAD_PRESET=safay_hub_unsigned
```

### Step 3: Restart Dev Server
```bash
# Stop server (Ctrl+C)
npm run dev
# or
bun run dev
```

### Step 4: Test Upload
```bash
# 1. Open app: http://localhost:5173
# 2. Go to Add Employee
# 3. Select a small test image
# 4. Open browser console (F12)
# 5. Try uploading
# 6. Check console for detailed error
```

### Step 5: Check Console Output
```javascript
// Look for these messages in console:
✅ "Compressing image..."
✅ "Compressed to XXX KB"
❌ "Cloudinary error response: {...}" // Check this!
```

---

## 📊 Debugging Commands

### Check Environment Variables at Runtime:
```javascript
// Add to AddEmployee.tsx temporarily
console.log('Cloud Name:', import.meta.env.VITE_CLOUDINARY_CLOUD_NAME);
console.log('Upload Preset:', import.meta.env.VITE_CLOUDINARY_UPLOAD_PRESET);

// Should log:
// Cloud Name: dcnw6lrcq
// Upload Preset: safay_hub_unsigned
```

### Test Direct Cloudinary Upload:
```bash
# Using curl (replace with actual image path)
curl -X POST \
  https://api.cloudinary.com/v1_1/dcnw6lrcq/image/upload \
  -F "upload_preset=safay_hub_unsigned" \
  -F "file=@/path/to/test-image.jpg"

# Success response includes:
# "secure_url": "https://res.cloudinary.com/..."
```

---

## 🔍 What Changed in Latest Fix

### Removed Parameters That Cause Issues:

**Before (Causing 400 Error):**
```typescript
formData.append("public_id", `${Date.now()}_${file.name.split('.')[0]}`);
formData.append("transformation", "q_auto,f_auto,w_800,h_800,c_limit");
```

**After (Fixed):**
```typescript
// Only essential parameters for unsigned upload
formData.append("file", file);
formData.append("upload_preset", uploadPreset);
formData.append("folder", folder); // optional
```

**Why?**
- `public_id` and `transformation` parameters require **signed uploads**
- With **unsigned uploads**, these must be configured in the preset itself
- Sending them causes a 400 Bad Request error

### Added Better Error Logging:

```typescript
// Now logs detailed error information
console.error("Cloudinary error response:", errorResponse);
if (errorResponse.error && errorResponse.error.message) {
  errorMessage += `: ${errorResponse.error.message}`;
}
```

---

## 💡 Pro Tips

### Configure Transformations in Preset:
Instead of sending transformations with each upload, configure them in the upload preset:

1. Go to upload preset settings
2. Add **Incoming Transformation**:
   - Width: 800
   - Height: 800
   - Crop: limit
   - Quality: auto:good
   - Format: auto

### Enable Automatic Optimization:
In upload preset:
- **Quality:** auto:good
- **Format:** auto (converts to WebP when supported)
- **Fetch format:** auto

---

## 📞 Still Not Working?

### Collect This Information:

1. **Browser Console Error**
   ```javascript
   // Copy full error from console
   Cloudinary error response: {...}
   ```

2. **Network Tab Response**
   - Open DevTools → Network
   - Find the failed request
   - Copy response body

3. **Environment Variables**
   ```bash
   echo $VITE_CLOUDINARY_CLOUD_NAME
   echo $VITE_CLOUDINARY_UPLOAD_PRESET
   ```

4. **Upload Preset Screenshot**
   - Take screenshot of your upload preset settings
   - Verify "Signing mode: Unsigned"

### Get Help:
- Check Cloudinary logs: https://cloudinary.com/console/logs
- Cloudinary support: https://support.cloudinary.com
- Test with Cloudinary's upload widget to verify account

---

## ✅ Success Indicators

When working correctly, you should see:

1. **Console logs:**
   ```
   Compressing image...
   Original size: 3200 KB
   Compressed to 180 KB (94% smaller)
   ```

2. **Network request:**
   ```
   Status: 200 OK
   Response: { secure_url: "https://res.cloudinary.com/..." }
   ```

3. **Toast notifications:**
   ```
   ✓ Photo uploaded successfully
   ✓ Aadhar uploaded successfully
   ✓ Employee added successfully
   ```

4. **Image appears** in All Workers page immediately

---

## 🎯 Most Likely Solution

**95% of 400 errors are caused by:**
1. Upload preset doesn't exist
2. Upload preset is not set to "Unsigned"
3. Upload preset name is misspelled

**Fix:** Go to Cloudinary Dashboard → Settings → Upload → Upload presets → Create/verify `safay_hub_unsigned` with **Unsigned** signing mode.

Then restart your dev server!
