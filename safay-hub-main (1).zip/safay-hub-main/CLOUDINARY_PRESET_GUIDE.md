# 📸 Visual Guide: Creating Cloudinary Upload Preset

## Step-by-Step with Screenshots

---

## Step 1: Login to Cloudinary

Navigate to: **https://cloudinary.com/console**

```
┌─────────────────────────────────────────┐
│  Cloudinary Console                     │
│  ┌───────────────────────────────────┐ │
│  │ Email: your-email@example.com     │ │
│  │ Password: ••••••••                │ │
│  │                                   │ │
│  │        [ Login ]                  │ │
│  └───────────────────────────────────┘ │
└─────────────────────────────────────────┘
```

---

## Step 2: Go to Settings

Click the **⚙️ Settings** icon in the top right corner

```
┌─────────────────────────────────────────────────┐
│  Cloudinary Dashboard            [👤] [⚙️]     │  ← Click here
├─────────────────────────────────────────────────┤
│                                                 │
│  Dashboard  Media Library  Reports  Settings   │
│                                                 │
│  Storage: 2.5GB / 25GB used                    │
│  Bandwidth: 150GB / 150GB used                 │
│                                                 │
└─────────────────────────────────────────────────┘
```

---

## Step 3: Navigate to Upload Tab

In Settings, click the **Upload** tab

```
┌─────────────────────────────────────────────────┐
│  Settings                                       │
├─────────────────────────────────────────────────┤
│  [Account] [Security] [Upload] [Media Library]  │  ← Click here
│                                                 │
│  Upload Configuration                           │
│                                                 │
└─────────────────────────────────────────────────┘
```

---

## Step 4: Find Upload Presets Section

Scroll down to **Upload presets**

```
┌─────────────────────────────────────────────────┐
│  Upload                                         │
├─────────────────────────────────────────────────┤
│                                                 │
│  Upload Configuration                           │
│  ├─ Auto Backup                                 │
│  ├─ Auto Tagging                                │
│  └─ Upload Presets                              │  ← Scroll here
│                                                 │
│  ┌─────────────────────────────────────────┐   │
│  │ Upload Presets                          │   │
│  │                                         │   │
│  │ Presets allow you to define settings   │   │
│  │ for your uploads.                       │   │
│  │                                         │   │
│  │ [+ Add upload preset]                   │   │  ← Click here
│  └─────────────────────────────────────────┘   │
└─────────────────────────────────────────────────┘
```

---

## Step 5: Create Upload Preset

Fill in the form:

```
┌─────────────────────────────────────────────────────────┐
│  Add Upload Preset                                      │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  Preset name *                                          │
│  ┌─────────────────────────────────────────────────┐   │
│  │ safay_hub_unsigned                              │   │  ← Type this
│  └─────────────────────────────────────────────────┘   │
│                                                         │
│  Signing mode *                                         │
│  ┌─────────────────────────────────────────────────┐   │
│  │ ⦿ Unsigned         ○ Signed                     │   │  ← Select Unsigned
│  └─────────────────────────────────────────────────┘   │
│                                                         │
│  ⚠️ Important: Must be Unsigned!                       │
│                                                         │
│  Use filename                                           │
│  ☑ Use the original filename                           │
│                                                         │
│  Unique filename                                        │
│  ☑ Add random characters to make filename unique       │
│                                                         │
│  Folder (Optional)                                      │
│  ┌─────────────────────────────────────────────────┐   │
│  │ Leave empty or set default folder               │   │
│  └─────────────────────────────────────────────────┘   │
│                                                         │
│              [Cancel]            [Save]                 │  ← Click Save
│                                                         │
└─────────────────────────────────────────────────────────┘
```

---

## Step 6: Verify Preset Created

You should see your preset in the list:

```
┌─────────────────────────────────────────────────────────┐
│  Upload Presets                                         │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  ┌─────────────────────────────────────────────────┐   │
│  │ Preset Name          Mode       Actions         │   │
│  ├─────────────────────────────────────────────────┤   │
│  │ safay_hub_unsigned   Unsigned   [Edit] [Delete] │   │  ← Your preset
│  └─────────────────────────────────────────────────┘   │
│                                                         │
│  ✅ Preset created successfully!                       │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

---

## Step 7: Copy Preset Name

Make sure it matches your `.env` file:

```
.env file:
┌─────────────────────────────────────────────────┐
│ VITE_CLOUDINARY_CLOUD_NAME=dcnw6lrcq           │
│ VITE_CLOUDINARY_UPLOAD_PRESET=safay_hub_unsigned │  ← Must match exactly!
└─────────────────────────────────────────────────┘
```

---

## Important Settings Checklist

When creating the preset, ensure:

### ✅ Required Settings:
- [x] **Preset name:** `safay_hub_unsigned`
- [x] **Signing mode:** **Unsigned** (not Signed!)

### ✅ Recommended Settings:
- [x] **Use filename:** Enabled
- [x] **Unique filename:** Enabled
- [x] **Folder:** Leave empty (we set this per upload)

### ❌ Don't Set These (Optional):
- [ ] Public ID prefix
- [ ] Tags
- [ ] Context
- [ ] Incoming transformation

---

## Common Mistakes to Avoid

### ❌ Wrong: Signing Mode = Signed
```
Signing mode: ○ Unsigned  ⦿ Signed  ← WRONG!
```
**Result:** 400 Bad Request error

### ✅ Correct: Signing Mode = Unsigned
```
Signing mode: ⦿ Unsigned  ○ Signed  ← CORRECT!
```
**Result:** Upload works!

---

### ❌ Wrong: Preset name typo
```
Preset name: safay_hub_unsignd  ← Missing 'e'
```
**Result:** Preset not found error

### ✅ Correct: Exact name match
```
Preset name: safay_hub_unsigned  ← Exact match
.env: VITE_CLOUDINARY_UPLOAD_PRESET=safay_hub_unsigned
```
**Result:** Upload works!

---

## Quick Verification

After creating the preset, verify in your Cloudinary dashboard:

```
Dashboard → Settings → Upload → Upload presets

Look for:
┌──────────────────────────────────────────┐
│ safay_hub_unsigned        Unsigned       │  ← Should exist
└──────────────────────────────────────────┘
```

---

## Testing the Preset

### Option 1: Use Test File
```bash
open test-cloudinary.html
```

### Option 2: Use Your App
```bash
# 1. Restart dev server
npm run dev

# 2. Open app
open http://localhost:5173

# 3. Go to Add Employee
# 4. Try uploading an image
```

---

## Success Indicators

### In Browser Console:
```javascript
✅ Compressing image...
✅ Original size: 3200 KB
✅ Compressed to 180 KB (94% smaller)
✅ Uploading to Cloudinary...
✅ Upload complete: https://res.cloudinary.com/...
```

### In UI:
```
Toast notifications:
✓ Photo compressed to 180 KB (94% smaller)
✓ Photo uploaded successfully
✓ Aadhar uploaded successfully
✓ Employee added successfully
```

---

## Troubleshooting

### If you see "Upload preset not found":
1. Check spelling in Cloudinary dashboard
2. Check spelling in `.env` file
3. They must match **exactly** (case-sensitive)

### If you see "Upload preset must be whitelisted":
1. Ensure signing mode is **Unsigned** (not Signed)
2. Save the preset again
3. Wait 30 seconds for changes to propagate

### If you see "Invalid signature":
1. Preset is set to **Signed** instead of **Unsigned**
2. Change to **Unsigned** and save

---

## Need More Help?

See detailed documentation:
- `FIX_CLOUDINARY_ERROR.md` - Quick fix guide
- `CLOUDINARY_UPLOAD_ERROR.md` - Complete troubleshooting
- `test-cloudinary.html` - Standalone test tool

---

## Summary

1. **Login** to Cloudinary Dashboard
2. **Go to** Settings → Upload → Upload presets
3. **Click** "Add upload preset"
4. **Enter:**
   - Name: `safay_hub_unsigned`
   - Mode: **Unsigned** ⚠️
5. **Save**
6. **Restart** dev server
7. **Test** upload

Done! 🚀
