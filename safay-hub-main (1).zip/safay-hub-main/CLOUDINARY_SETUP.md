# Cloudinary Setup Guide 🖼️

## Complete Step-by-Step Guide to Configure Cloudinary

Since you already have a Cloudinary account, let's get your credentials and set up the upload preset!

---

## Step 1: Get Your Cloud Name ☁️

1. Go to [Cloudinary Dashboard](https://cloudinary.com/console)
2. Log in to your account
3. On the **Dashboard** (home page), you'll see your **Cloud name** at the top
4. Copy this value (e.g., "dxyz123abc")

---

## Step 2: Create an Upload Preset 🔑

An **upload preset** allows unsigned uploads (so you can upload from the browser without exposing API secrets).

### Steps:

1. In Cloudinary Console, go to **Settings** (gear icon in top right)
2. Click on the **Upload** tab in the left sidebar
3. Scroll down to **Upload presets** section
4. Click **Add upload preset**

### Configure the Upload Preset:

Fill in these settings:

- **Preset name**: `safay_hub_unsigned` (or any name you prefer)
- **Signing Mode**: Select **"Unsigned"** ⚠️ (This is IMPORTANT!)
- **Folder**: Leave empty or set to `safay-hub` (optional)
- **Access Mode**: `public` (so images can be viewed)
- **Unique filename**: Enable this (recommended)
- **Overwrite**: Disable (to prevent accidental overwrites)

5. Click **Save** at the bottom

6. **Copy the preset name** you just created

---

## Step 3: Update Your .env File 📝

Now open your `.env` file and add your credentials:

```env
# Cloudinary Configuration
VITE_CLOUDINARY_CLOUD_NAME=your_cloud_name_here
VITE_CLOUDINARY_UPLOAD_PRESET=safay_hub_unsigned
```

### Example:
```env
VITE_CLOUDINARY_CLOUD_NAME=dxyz123abc
VITE_CLOUDINARY_UPLOAD_PRESET=safay_hub_unsigned
```

Replace:
- `dxyz123abc` with YOUR actual cloud name
- `safay_hub_unsigned` with YOUR actual upload preset name

---

## Step 4: Verify Your Setup ✅

1. Save the `.env` file
2. **Restart your development server**:
   ```bash
   # Stop the current server (Ctrl+C)
   # Then restart:
   npm run dev
   ```

3. Test the upload:
   - Go to "Add Employee" page
   - Fill in the form
   - Upload photos
   - Submit

---

## Step 5: Verify in Cloudinary 🎉

1. Go to [Cloudinary Media Library](https://cloudinary.com/console/media_library)
2. You should see your uploaded images in folders:
   - `employees/photos/`
   - `employees/aadhar/`

---

## Quick Reference 📋

### Where to Find Things:

| What You Need | Where to Find It |
|---------------|------------------|
| **Cloud Name** | Dashboard home page (top section) |
| **Upload Preset** | Settings > Upload > Upload presets |
| **Media Library** | Left sidebar > Media Library |
| **Usage Stats** | Dashboard > Account Details |

---

## Cloudinary Free Tier Limits 🎁

Your free account includes:

- ✅ **25 GB Storage**
- ✅ **25 GB Bandwidth/month**
- ✅ **Unlimited transformations**
- ✅ **Multiple folder organization**
- ✅ **CDN delivery**

This is **much more generous** than Firebase Storage! 🚀

---

## Folder Structure in Cloudinary

Your images will be automatically organized like this:

```
Cloudinary Media Library/
├── employees/
│   ├── photos/
│   │   ├── 1730812345678_john_smith.jpg
│   │   ├── 1730812456789_jane_doe.jpg
│   │   └── ...
│   └── aadhar/
│       ├── 1730812345678_john_aadhar.jpg
│       ├── 1730812456789_jane_aadhar.jpg
│       └── ...
```

---

## Common Issues & Solutions 🔧

### Issue 1: "Cloudinary credentials not configured"
**Solution**: 
- Check that `.env` file has the correct values
- Make sure variable names start with `VITE_`
- Restart the dev server after editing `.env`

### Issue 2: "Upload failed with status 400"
**Solution**: 
- Verify the upload preset is set to **"Unsigned"** mode
- Check the preset name is spelled correctly
- Make sure the preset is **active** (not disabled)

### Issue 3: Images not showing in Media Library
**Solution**: 
- Check the folder path (look in root folder or `employees` folder)
- Verify upload was successful (check browser console)
- Refresh the Media Library page

### Issue 4: "Invalid cloud name"
**Solution**: 
- Double-check you copied the cloud name exactly (no spaces)
- Cloud name is case-sensitive
- Don't include the full URL, just the name

---

## Optimizations (Optional) 🎨

Cloudinary can automatically optimize your images! In your upload preset:

1. **Enable Auto Optimization**:
   - Format: `auto`
   - Quality: `auto`

2. **Set Max Dimensions** (to save space):
   - Width: `1920px`
   - Height: `1920px`
   - Crop mode: `limit`

This will reduce file sizes without losing quality!

---

## Advanced: Image Transformations 🔥

Cloudinary can transform images on-the-fly! For example, to get a thumbnail:

```
Original URL:
https://res.cloudinary.com/dxyz123abc/image/upload/v123/employees/photos/image.jpg

Thumbnail (200x200):
https://res.cloudinary.com/dxyz123abc/image/upload/w_200,h_200,c_fill/v123/employees/photos/image.jpg
```

You can add these transformations later if needed!

---

## Security Best Practices 🔒

✅ **Do's:**
- Use unsigned presets for browser uploads
- Set folder restrictions in preset settings
- Use unique filenames (enabled by default)
- Monitor your usage in the dashboard

❌ **Don'ts:**
- Don't expose your API Secret (it's not needed for uploads)
- Don't commit `.env` file to git (already in `.gitignore`)
- Don't use signed uploads from browser (requires API secret)

---

## Testing Checklist ✅

Before moving forward, verify:

- [ ] Cloud name is correct in `.env`
- [ ] Upload preset is created and set to "Unsigned"
- [ ] Upload preset name is correct in `.env`
- [ ] Dev server is restarted
- [ ] Can upload employee photo successfully
- [ ] Can upload Aadhar photo successfully
- [ ] Images appear in Cloudinary Media Library
- [ ] Images display correctly in "All Workers" page

---

## What's Different from Firebase Storage? 🤔

| Feature | Firebase Storage | Cloudinary |
|---------|-----------------|------------|
| Free Storage | 5 GB | **25 GB** ⭐ |
| Free Bandwidth | 1 GB/day | **25 GB/month** ⭐ |
| Image Optimization | Manual | **Automatic** ⭐ |
| Transformations | No | **Yes** ⭐ |
| CDN | Yes | Yes |
| Ease of Setup | Medium | **Easy** ⭐ |

---

## Next Steps 🚀

Once everything works:

1. ✅ Your images are now stored in Cloudinary (not Firebase Storage)
2. ✅ Your data is still in Firestore (employees, inquiries, etc.)
3. ✅ You have **25 GB free storage** for images!
4. 🎉 You're using the best of both worlds!

---

## Need Help? 🆘

- **Cloudinary Docs**: https://cloudinary.com/documentation
- **Upload Presets Guide**: https://cloudinary.com/documentation/upload_presets
- **API Reference**: https://cloudinary.com/documentation/image_upload_api_reference

---

## Your Current Stack 📚

- **Frontend**: React + TypeScript + Vite
- **Database**: Firebase Firestore ✅
- **Image Storage**: Cloudinary ✅
- **UI**: shadcn-ui + Tailwind CSS

Perfect combination! 🎉

---

**Questions? Check your Cloudinary dashboard or browser console for error messages!**
