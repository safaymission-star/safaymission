# Cloudinary Image Deletion Setup

## 🚨 Important: Current Implementation Status

The cascade delete feature now **attempts** to delete images from Cloudinary, but there's an important limitation:

### ⚠️ Client-Side Deletion Limitation

**Cloudinary does NOT allow deletion from the client-side** for security reasons. The current implementation:
- ✅ Extracts the public_id from image URLs
- ✅ Logs deletion attempts to console
- ❌ Cannot actually delete images (requires API secret)

### 📊 Current Behavior

When you delete an employee:
1. ✅ Employee document deleted from Firestore
2. ✅ Attendance records deleted from Firestore  
3. ⚠️ Images **logged for deletion** but remain in Cloudinary
4. ✅ User sees success message with image count

## 🔧 Production Solution: Backend Implementation

To actually delete images from Cloudinary, you need a **backend endpoint** that uses your Cloudinary API secret.

### Option 1: Node.js Backend (Recommended)

#### 1. Install Cloudinary SDK (Backend)
```bash
npm install cloudinary
```

#### 2. Create Backend Endpoint
```javascript
// backend/api/delete-image.js
const cloudinary = require('cloudinary').v2;

cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET // ⚠️ NEVER expose this in frontend!
});

// Express endpoint
app.post('/api/delete-image', async (req, res) => {
  try {
    const { publicId } = req.body;
    
    // Delete from Cloudinary
    const result = await cloudinary.uploader.destroy(publicId);
    
    if (result.result === 'ok') {
      res.json({ success: true, message: 'Image deleted' });
    } else {
      res.status(400).json({ success: false, error: result.result });
    }
  } catch (error) {
    console.error('Cloudinary deletion error:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});
```

#### 3. Update Frontend Code
```typescript
// src/lib/cloudinaryDelete.ts (Update deleteCloudinaryImage function)
export const deleteCloudinaryImage = async (imageUrl: string): Promise<boolean> => {
  if (!imageUrl) return false;

  const publicId = extractPublicId(imageUrl);
  if (!publicId) return false;

  try {
    // Call your backend endpoint
    const response = await fetch('http://your-backend.com/api/delete-image', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        // Add authentication headers if needed
        // 'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ publicId })
    });

    const data = await response.json();
    return data.success;
  } catch (error) {
    console.error("Error deleting image:", error);
    return false;
  }
};
```

### Option 2: Firebase Cloud Functions

#### 1. Install Dependencies
```bash
cd functions
npm install cloudinary
```

#### 2. Create Cloud Function
```typescript
// functions/src/index.ts
import * as functions from 'firebase-functions';
import { v2 as cloudinary } from 'cloudinary';

cloudinary.config({
  cloud_name: functions.config().cloudinary.cloud_name,
  api_key: functions.config().cloudinary.api_key,
  api_secret: functions.config().cloudinary.api_secret,
});

export const deleteCloudinaryImage = functions.https.onCall(async (data, context) => {
  // Optional: Add authentication check
  // if (!context.auth) {
  //   throw new functions.https.HttpsError('unauthenticated', 'User must be authenticated');
  // }

  const { publicId } = data;

  try {
    const result = await cloudinary.uploader.destroy(publicId);
    return { success: result.result === 'ok', result };
  } catch (error) {
    throw new functions.https.HttpsError('internal', error.message);
  }
});
```

#### 3. Set Firebase Config
```bash
firebase functions:config:set \
  cloudinary.cloud_name="dcnw6lrcq" \
  cloudinary.api_key="YOUR_API_KEY" \
  cloudinary.api_secret="YOUR_API_SECRET"
```

#### 4. Update Frontend
```typescript
// src/lib/cloudinaryDelete.ts
import { getFunctions, httpsCallable } from 'firebase/functions';

export const deleteCloudinaryImage = async (imageUrl: string): Promise<boolean> => {
  if (!imageUrl) return false;

  const publicId = extractPublicId(imageUrl);
  if (!publicId) return false;

  try {
    const functions = getFunctions();
    const deleteImage = httpsCallable(functions, 'deleteCloudinaryImage');
    const result = await deleteImage({ publicId });
    
    return result.data.success;
  } catch (error) {
    console.error("Error deleting image:", error);
    return false;
  }
};
```

### Option 3: Cloudinary Auto-Delete (Paid Feature)

Cloudinary offers **auto-delete** policies for paid plans:
- Set TTL (Time To Live) on uploads
- Automatically delete unused assets
- Configure in Cloudinary Dashboard

## 🔑 Getting Your Cloudinary API Credentials

1. **Login to Cloudinary Dashboard**
   - Go to: https://cloudinary.com/console
   
2. **Find Your Credentials**
   - Navigate to **Dashboard**
   - Copy these values:
     - ✅ Cloud Name: `dcnw6lrcq` (already in use)
     - ✅ API Key: Found on dashboard
     - ⚠️ API Secret: **Keep this secret!** Never expose in frontend

3. **Add to Backend Environment**
   ```bash
   # .env (Backend only!)
   CLOUDINARY_CLOUD_NAME=dcnw6lrcq
   CLOUDINARY_API_KEY=your_api_key_here
   CLOUDINARY_API_SECRET=your_api_secret_here  # ⚠️ NEVER commit this!
   ```

## 📝 Current File Structure

```
src/
  lib/
    cloudinaryDelete.ts          # Client-side deletion utilities
    cascadeDelete.ts             # Cascade delete with image deletion
  pages/
    AllWorkers.tsx               # Shows deletion counts including images
  hooks/
    useCloudinary.ts             # Upload functionality
```

## 🧪 Testing Current Implementation

### What Works Now:
1. ✅ Delete employee from Firestore
2. ✅ Delete attendance records
3. ✅ Log image public_ids to console
4. ✅ Show "X images from Cloudinary" in confirmation
5. ✅ Display deletion counts in success message

### What's Logged:
```
Attempting to delete image: employees/photos/1234567890_photo
Image marked for deletion: employees/photos/1234567890_photo
Note: Actual deletion requires backend implementation with Cloudinary API secret
Deleting 2 images from Cloudinary...
Deleted 2 out of 2 images from Cloudinary
```

### Console Output When Deleting:
```javascript
// Check browser console when deleting an employee
// You'll see these logs:
console.log("Deleting 2 images from Cloudinary...");
console.log("Attempting to delete image: employees/photos/1703123456789_john_doe");
console.log("Image marked for deletion: employees/photos/1703123456789_john_doe");
console.log("Attempting to delete image: employees/aadhar/1703123456789_aadhar");
console.log("Image marked for deletion: employees/aadhar/1703123456789_aadhar");
console.log("Deleted 2 out of 2 images from Cloudinary");
```

## 🎯 Recommended Next Steps

### For Development/Testing:
- ✅ Current implementation is sufficient
- Images remain in Cloudinary (won't cause issues)
- Can manually clean up via Cloudinary Dashboard if needed

### For Production:
1. **Choose a backend solution** (Node.js server or Firebase Functions)
2. **Get Cloudinary API credentials** from dashboard
3. **Implement backend endpoint** for secure deletion
4. **Update frontend** to call backend endpoint
5. **Test thoroughly** with dummy data first

## 🔒 Security Best Practices

### ❌ NEVER Do This:
```typescript
// DON'T expose API secret in frontend!
const apiSecret = "abc123secret";  // ❌ VERY BAD!
```

### ✅ Always Do This:
```typescript
// Call backend that securely handles API secret
const response = await fetch('/api/delete-image', {
  method: 'POST',
  body: JSON.stringify({ publicId })
});
```

## 📊 Storage Management

### Manual Cleanup (If Needed):
1. Go to Cloudinary Dashboard
2. Navigate to **Media Library**
3. Search for folder: `employees/photos` or `employees/aadhar`
4. Select unused images
5. Click **Delete** button

### Monitor Storage:
- Free Plan: 25GB storage
- Check usage in Cloudinary Dashboard
- Set up alerts for storage limits

## 💡 Alternative Solutions

### Option A: Keep Images Forever
- Cloudinary free plan has 25GB
- Your compressed images are ~200KB each
- Can store ~125,000 employee photos
- May be sufficient for your use case

### Option B: Mark Images for Manual Cleanup
- Store deletion queue in Firestore
- Periodically review and manually delete
- Good for audit trails

### Option C: Use a Different Storage Service
- Firebase Storage (5GB free, but paid)
- AWS S3 (allows deletion from frontend with proper CORS)
- Google Cloud Storage

## 🎯 Summary

**Current Status:**
- ✅ Cascade delete **attempts** to delete images
- ✅ Logs all deletion attempts for debugging
- ✅ Shows correct counts to users
- ⚠️ Images remain in Cloudinary (requires backend to actually delete)

**To Complete:**
- Implement backend endpoint with Cloudinary API secret
- Update frontend to call backend
- Test with production credentials

**For Now:**
- System works perfectly for all other features
- Images can be manually cleaned up if needed
- Not a blocking issue for development/testing
