# Firebase Setup Guide for Safay Hub

This guide will help you set up Firebase for your Safay Hub application.

## Prerequisites

- A Google account
- Node.js and npm installed

## Step 1: Create a Firebase Project

1. Go to the [Firebase Console](https://console.firebase.google.com/)
2. Click on "Add project" or "Create a project"
3. Enter your project name (e.g., "safay-hub")
4. Follow the setup wizard:
   - Enable Google Analytics (optional)
   - Choose or create a Google Analytics account (if enabled)
5. Click "Create project"

## Step 2: Register Your App

1. In your Firebase project, click on the web icon (`</>`) to add a web app
2. Enter an app nickname (e.g., "Safay Hub Web")
3. Check "Also set up Firebase Hosting" (optional)
4. Click "Register app"

## Step 3: Get Firebase Configuration

1. After registering, you'll see your Firebase configuration
2. Copy the configuration object that looks like this:

```javascript
const firebaseConfig = {
  apiKey: "AIzaSy...",
  authDomain: "your-project.firebaseapp.com",
  projectId: "your-project",
  storageBucket: "your-project.appspot.com",
  messagingSenderId: "123456789",
  appId: "1:123456789:web:abcdef",
  measurementId: "G-XXXXXXXXXX"
};
```

## Step 4: Configure Environment Variables

1. Open the `.env` file in your project root
2. Replace the placeholder values with your Firebase configuration:

```env
VITE_FIREBASE_API_KEY=your_api_key_here
VITE_FIREBASE_AUTH_DOMAIN=your_project_id.firebaseapp.com
VITE_FIREBASE_PROJECT_ID=your_project_id
VITE_FIREBASE_STORAGE_BUCKET=your_project_id.appspot.com
VITE_FIREBASE_MESSAGING_SENDER_ID=your_sender_id
VITE_FIREBASE_APP_ID=your_app_id
VITE_FIREBASE_MEASUREMENT_ID=your_measurement_id
```

⚠️ **Important**: Never commit the `.env` file to version control. It's already in `.gitignore`.

## Step 5: Enable Firestore Database

1. In the Firebase Console, go to **Firestore Database**
2. Click "Create database"
3. Choose "Start in **test mode**" (for development) or "Start in **production mode**" (for production)
4. Select a location for your database (choose the closest to your users)
5. Click "Enable"

### Firestore Security Rules (Production)

For production, update your Firestore rules:

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Employees collection
    match /employees/{employeeId} {
      allow read: if true;
      allow write: if request.auth != null;
    }
    
    // Inquiries collection
    match /inquiries/{inquiryId} {
      allow read, write: if request.auth != null;
    }
    
    // Payments collection
    match /payments/{paymentId} {
      allow read, write: if request.auth != null;
    }
    
    // Pending works collection
    match /pendingWorks/{workId} {
      allow read, write: if request.auth != null;
    }
  }
}
```

## Step 6: Enable Firebase Storage

1. In the Firebase Console, go to **Storage**
2. Click "Get started"
3. Review the security rules and click "Next"
4. Choose a location (same as Firestore is recommended)
5. Click "Done"

### Storage Security Rules (Production)

For production, update your Storage rules:

```javascript
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /employees/{allPaths=**} {
      allow read: if true;
      allow write: if request.auth != null;
    }
  }
}
```

## Step 7: (Optional) Enable Authentication

If you plan to add user authentication later:

1. Go to **Authentication** in the Firebase Console
2. Click "Get started"
3. Enable the sign-in methods you want (Email/Password, Google, etc.)

## Step 8: Test Your Setup

1. Start your development server:
```bash
npm run dev
```

2. Try adding an employee through the "Add Employee" page
3. Check if the data appears in Firestore Database
4. Check if the images are uploaded to Storage

## Firestore Collections

Your app uses the following Firestore collections:

- **employees**: Stores employee information
  - Fields: `name`, `address`, `contact`, `photoUrl`, `aadharPhotoUrl`, `createdAt`, `updatedAt`

- **inquiries**: Stores customer inquiries
  - Fields: `name`, `email`, `message`, `createdAt`, `updatedAt`

- **payments**: Stores payment records
  - Fields: `amount`, `date`, `createdAt`, `updatedAt`

- **pendingWorks**: Stores pending work items
  - Fields: `title`, `description`, `status`, `createdAt`, `updatedAt`

## Storage Structure

```
storage/
├── employees/
│   ├── photos/
│   │   └── timestamp_filename.jpg
│   └── aadhar/
│       └── timestamp_filename.jpg
```

## Troubleshooting

### "Firebase: Error (auth/configuration-not-found)"
- Make sure you've copied all environment variables correctly
- Restart your development server after updating `.env`

### "FirebaseError: Missing or insufficient permissions"
- Check your Firestore security rules
- Make sure you're in test mode during development

### Images not uploading
- Check your Storage security rules
- Verify that the Storage bucket is enabled
- Check browser console for detailed error messages

### "Firebase: Firebase App named '[DEFAULT]' already exists"
- This usually happens during hot-reload in development
- Simply refresh the page

## Next Steps

1. **Add Authentication**: Implement user login to secure your admin panel
2. **Update Security Rules**: Switch from test mode to production rules
3. **Add Indexes**: Create composite indexes for complex queries
4. **Enable Offline Persistence**: For better user experience
5. **Set up Firebase Hosting**: Deploy your app to Firebase

## Useful Links

- [Firebase Documentation](https://firebase.google.com/docs)
- [Firestore Documentation](https://firebase.google.com/docs/firestore)
- [Storage Documentation](https://firebase.google.com/docs/storage)
- [Firebase Console](https://console.firebase.google.com/)

## Support

If you encounter any issues, check:
1. Browser console for error messages
2. Firebase Console for quota limits
3. Network tab to verify API calls

---

**Remember**: Keep your Firebase configuration secure and never expose your API keys in public repositories!
